package coe528.lab3;

/**
 *
 * @author AbdullahPC
 */
public interface Counter {
    String count();
    void increment();
    void decrement();
    void reset();
}
