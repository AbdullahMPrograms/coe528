package coe528.project;

import java.text.NumberFormat;
import java.util.Optional;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GUIDriver extends Application {
    private static Manager manager = new Manager("admin", "admin", "manager");

    private Scene loginScene(Stage stage) {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);

        Label nameLabel = new Label("Username:");
        TextField nameInput = new TextField();
        nameInput.setPromptText("Enter your username");
        GridPane.setConstraints(nameLabel, 0, 0);
        GridPane.setConstraints(nameInput, 1, 0);

        Label passLabel = new Label("Password:");
        PasswordField passInput = new PasswordField();
        passInput.setPromptText("Enter your password");
        GridPane.setConstraints(passLabel, 0, 1);
        GridPane.setConstraints(passInput, 1, 1);

        Label roleLabel = new Label("Role:");
        ChoiceBox<String> roleInput = new ChoiceBox<>();
        roleInput.getItems().addAll("manager", "customer");
        roleInput.setValue("customer");
        GridPane.setConstraints(roleLabel, 0, 2);
        GridPane.setConstraints(roleInput, 1, 2);

        Button loginButton = new Button("Log In");
        GridPane.setConstraints(loginButton, 1, 3);

        loginButton.setOnAction(e -> {
            String username = nameInput.getText();
            String password = passInput.getText();
            String role = roleInput.getValue();

            if (role.equals("manager")) {
                if (manager.authenticate(username, password, role)) {
                    stage.setScene(managerMenu(stage));
                } else {
                    showAlert(Alert.AlertType.ERROR, "Invalid manager credentials.");
                }
            } else if (role.equals("customer")) {
                Customer customer = Customer.loadFromFile(username);
                if (customer != null && customer.authenticate(username, password, role)) {
                    stage.setScene(customerMenu(stage, customer));
                } else {
                    showAlert(Alert.AlertType.ERROR, "Invalid customer credentials.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Invalid role.");
            }
        });

        grid.getChildren().addAll(nameLabel, nameInput, passLabel, passInput, roleLabel, roleInput, loginButton);
        grid.setAlignment(Pos.CENTER);

        return new Scene(grid, 300, 200);
    }

    private Scene managerMenu(Stage stage) {
        stage.setTitle("Manager Menu");
        VBox vbox = new VBox(20);

        Button addCustomerButton = new Button("Add Customer");
        addCustomerButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Add Customer");
            dialog.setHeaderText("Enter the customer's username and password.");
            dialog.setContentText("Username:");

            Optional<String> usernameResult = dialog.showAndWait();
            if (usernameResult.isPresent()) {
                String username = usernameResult.get();

                dialog.setContentText("Password:");
                Optional<String> passwordResult = dialog.showAndWait();
                if (passwordResult.isPresent()) {
                    String password = passwordResult.get();
                    try {
                        manager.addCustomer(username, password, 100);
                        showAlert(Alert.AlertType.INFORMATION, "Customer added successfully.");
                    } catch (Exception ex) {
                        showAlert(Alert.AlertType.ERROR, ex.getMessage());
                    }
                }
            }
        });

        Button deleteCustomerButton = new Button("Delete Customer");
        deleteCustomerButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Delete Customer");
            dialog.setHeaderText("Enter the customer's username.");
            dialog.setContentText("Username:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String username = result.get();
                try {
                    manager.deleteCustomer(username);
                    showAlert(Alert.AlertType.INFORMATION, "Customer deleted successfully.");
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, ex.getMessage());
                }
            }
        });

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            stage.setScene(loginScene(stage));
        });

        vbox.getChildren().addAll(addCustomerButton, deleteCustomerButton, logoutButton);

        return new Scene(vbox, 300, 200);
    }

    private Scene customerMenu(Stage stage, Customer customer) {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
        VBox vbox = new VBox(10);

        Button depositButton = new Button("Deposit");
        depositButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Deposit");
            dialog.setHeaderText("Enter the deposit amount.");
            dialog.setContentText("Amount:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                double depositAmount = Double.parseDouble(result.get());
                try {
                    customer.deposit(depositAmount);
                    showAlert(Alert.AlertType.INFORMATION, "Deposit successful. Amount deposited: " + currencyFormat.format(depositAmount) + "\nCurrent balance: " + currencyFormat.format(customer.getBalance()));
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, ex.getMessage());
                }
            }
        });

        Button withdrawButton = new Button("Withdraw");
        withdrawButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Withdraw");
            dialog.setHeaderText("Enter the withdrawal amount.");
            dialog.setContentText("Amount:");
        
            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                double withdrawalAmount = Double.parseDouble(result.get());
                try {
                    customer.withdraw(withdrawalAmount);
                    showAlert(Alert.AlertType.INFORMATION, "Withdrawal successful. Amount withdrawn: " + currencyFormat.format(withdrawalAmount) + "\nCurrent balance: " + currencyFormat.format(customer.getBalance()));
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, ex.getMessage());
                }
            }
        });

        Button balanceButton = new Button("Get Balance");
        balanceButton.setOnAction(e -> {
            String customerLevel;
            if (customer.getLevel().getClass() == SilverLevel.class) {
                customerLevel = "Silver";
            } else if (customer.getLevel().getClass() == GoldLevel.class) {
                customerLevel = "Gold";
            } else {
                customerLevel = "Platinum";
            }
            showAlert(Alert.AlertType.INFORMATION, "Current balance: " + currencyFormat.format(customer.getBalance()) + "\nBanking Level: " + customerLevel);
        });

        Button purchaseButton = new Button("Online Purchase");
        purchaseButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Online Purchase");
            dialog.setHeaderText("Enter the purchase amount.");
            dialog.setContentText("Amount:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                double purchaseAmount = Double.parseDouble(result.get());
                double fee = 0;
                double totalCost = 0;
                if (customer.getLevel().getClass() == SilverLevel.class) {
                    fee = 20;
                } else if (customer.getLevel().getClass() == GoldLevel.class) {
                    fee = 10;
                }
                totalCost = purchaseAmount + fee;
                try {
                    customer.onlinePurchase(purchaseAmount);
                    showAlert(Alert.AlertType.INFORMATION, "Purchase successful.\nItem amount: " + currencyFormat.format(purchaseAmount) + "\nFee Incurred: " + currencyFormat.format(fee) + "\nTotal Cost: " + currencyFormat.format(totalCost));
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, ex.getMessage());
                }
            }
        });

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            stage.setScene(loginScene(stage));
        });

        vbox.getChildren().addAll(depositButton, withdrawButton, balanceButton, purchaseButton, logoutButton);

        return new Scene(vbox, 300, 200);
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Malik Banking");

        stage.setScene(loginScene(stage));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
