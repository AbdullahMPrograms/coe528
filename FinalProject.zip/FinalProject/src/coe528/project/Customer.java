package coe528.project;

import java.io.*;
import java.util.*;

public class Customer extends User {
    private double balance;
    private CustomerLevel level;

    public Customer(String username, String password, String role, double balance) {
        super(username, password, role);
        this.balance = balance;
        updateLevel();
    }

    public void deposit(double amount) throws Exception {
        if(amount > 0) {
            balance += amount;
            updateLevel();
            saveToFile();
        } else {
            throw new Exception("Amount must be greater then $0.00.");
        }

    }

    public void withdraw(double amount) throws Exception {
        if (balance >= amount) {
            balance -= amount;
            updateLevel();
            saveToFile();
        } else {
            throw new Exception("Insufficient balance.");
        }
    }

    public double getBalance() {
        return balance;
    }

    public void onlinePurchase(double amount) throws Exception {
        level.onlinePurchase(amount, this);
        updateLevel();
        saveToFile();
    }

    public CustomerLevel getLevel() {
        return level;
    }

    private void updateLevel() {
        if (balance < 10000) {
            level = new SilverLevel();
        } else if (balance < 20000) {
            level = new GoldLevel();
        } else {
            level = new PlatinumLevel();
        }
    }

    public void saveToFile() {
        try {
            FileWriter writer = new FileWriter(username + ".txt");
            writer.write(username + "," + password + "," + role + "," + balance);
            writer.close();
        } catch (IOException e) {
            System.out.println("Error saving customer data.");
        }
    }

    public static Customer loadFromFile(String username) {
        try {
            File file = new File(username + ".txt");
            Scanner scanner = new Scanner(file);
            String[] data = scanner.nextLine().split(",");
            scanner.close();
            return new Customer(data[0], data[1], data[2], Double.parseDouble(data[3]));
        } catch (FileNotFoundException e) {
            System.out.println("Customer not found.");
            return null;
        }
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
