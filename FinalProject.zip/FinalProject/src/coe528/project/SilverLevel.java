package coe528.project;

public class SilverLevel implements CustomerLevel {
    public void onlinePurchase(double amount, Customer customer) throws Exception {
        if (amount >= 50) {
            double totalAmount = amount + 20;
            if (customer.getBalance() >= totalAmount) {
                customer.setBalance(customer.getBalance() - totalAmount);
                System.out.println("Online purchase successful. $20 fee charged.");
            } else {
                System.out.println("Insufficient balance.");
            }
        } else {
            throw new Exception("Online purchase amount must be at least $50.");
        }
    }
}
