package coe528.project;

public class PlatinumLevel implements CustomerLevel {
    public void onlinePurchase(double amount, Customer customer) throws Exception {
        if (amount >= 50) {
            if (customer.getBalance() >= amount) {
                customer.setBalance(customer.getBalance() - amount);
                System.out.println("Online purchase successful. No fee charged.");
            } else {
                System.out.println("Insufficient balance.");
            }
        } else {
            throw new Exception("Online purchase amount must be at least $50.");
        }
    }
}
