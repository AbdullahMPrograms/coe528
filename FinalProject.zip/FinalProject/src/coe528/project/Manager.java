package coe528.project;

import java.io.File;

/**
 * Overview: Manager is a mutable class that extends User. It represents a manager in a banking system
 * who can add and delete customers.
 *
 * Abstraction Function:
 * A Manager m represents a manager with username m.username, password m.password, and role m.role.
 *
 * Representation Invariant:
 * - m.username != null
 * - m.password != null
 * - m.role == "manager"
 */
public class Manager extends User {
    /**
     * Creates a new Manager with the specified username, password, and role.
     *
     * @param username the username of the manager
     * @param password the password of the manager
     * @param role the role of the manager
     * @requires username != null, password != null, role == "manager"
     * @modifies this
     * @effects creates a new Manager with the given username, password, and role
     */
    public Manager(String username, String password, String role) {
        super(username, password, role);
        assert repOk();
    }

    /**
     * Adds a new customer with the given username, password, and initial balance.
     *
     * @param username the username of the customer
     * @param password the password of the customer
     * @param initialBalance the initial balance of the customer
     * @requires username != null, password != null, initialBalance != null
     * @modifies this
     * @effects creates a new Customer and saves it to a file, provided the username is not already in use
     */
    public void addCustomer(String username, String password, double initialBalance) throws Exception {
        assert repOk();
        File file = new File(username + ".txt");
        if(file.exists()) {
            throw new Exception("Customer already exists.");
        }
        Customer customer = new Customer(username, password, "customer", initialBalance);
        customer.saveToFile();
        assert repOk();
    }

    /**
     * Deletes the customer with the given username.
     *
     * @param username the username of the customer to delete
     * @requires username != null
     * @modifies this
     * @effects deletes the file associated with the customer with the given username
     */
    public void deleteCustomer(String username) {
        assert repOk();
        File file = new File(username + ".txt");
        file.delete();
        assert repOk();
    }

    /**
     * Returns a string representation of this Manager.
     *
     * @return a string representation of this Manager
     */
    @Override
    public String toString() {
        return "Manager{" + "username='" + username + '\'' + ", password='" + password + '\'' + ", role='" + role + '\'' + '}';
    }

    /**
     * Checks if the representation invariant holds for this Manager.
     *
     * @return true if the representation invariant holds, otherwise false
     */
    public boolean repOk() {
        return username != null && password != null && role.equals("manager");
    }
}