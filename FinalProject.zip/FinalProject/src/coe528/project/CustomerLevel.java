package coe528.project;

public interface CustomerLevel {
    void onlinePurchase(double amount, Customer customer) throws Exception;
}
