package coe528.project;
import java.util.*;

// CLI INTERFACE

public class TextDriver {
    private static Manager manager = new Manager("admin", "admin", "manager");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.next();
                    System.out.print("Enter password: ");
                    String password = scanner.next();
                    System.out.print("Enter role (manager/customer): ");
                    String role = scanner.next();

                    if (role.equals("manager")) {
                        if (manager.authenticate(username, password, role)) {
                            managerMenu(scanner);
                        } else {
                            System.out.println("Invalid manager credentials.");
                        }
                    } else if (role.equals("customer")) {
                        Customer customer = Customer.loadFromFile(username);
                        if (customer != null && customer.authenticate(username, password, role)) {
                            customerMenu(scanner, customer);
                        } else {
                            System.out.println("Invalid customer credentials.");
                        }
                    } else {
                        System.out.println("Invalid role.");
                    }
                    break;
                case 2:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void managerMenu(Scanner scanner) {
        while (true) {
            System.out.println("1. Add Customer");
            System.out.println("2. Delete Customer");
            System.out.println("3. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter customer username: ");
                    String username = scanner.next();
                    System.out.print("Enter customer password: ");
                    String password = scanner.next();
                    try {
                        manager.addCustomer(username, password, 100);
                        System.out.println("Customer added successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Enter customer username: ");
                    username = scanner.next();
                    try {
                        manager.deleteCustomer(username);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("Customer deleted successfully.");
                    break;
                case 3:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void customerMenu(Scanner scanner, Customer customer) {
        while (true) {
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Get Balance");
            System.out.println("4. Online Purchase");
            System.out.println("5. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scanner.nextDouble();
                    try {
                        customer.deposit(depositAmount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("Deposit successful.");
                    break;
                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawalAmount = scanner.nextDouble();
                    try {
                        customer.withdraw(withdrawalAmount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Current balance: $" + customer.getBalance());
                    break;
                case 4:
                    System.out.print("Enter purchase amount: ");
                    double purchaseAmount = scanner.nextDouble();
                    try {
                        customer.onlinePurchase(purchaseAmount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
